public void dropIn (View view){
    ImageView counter = (ImageView) view;
    counter.setTranslation(-1000f);
    counter.setImageResource(R.drawable.yellow);
    counter.animate().translationYBy(1000f).setDuration(300);

}
